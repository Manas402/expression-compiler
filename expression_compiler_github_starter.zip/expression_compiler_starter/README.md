# Expression Compiler

A student project that demonstrates the stages of compiling relational and logical expressions, with a web interface built using Flask.

> **Project status:** Starter documentation. Update this README to match the final code and tested behavior before submission. Do not claim a feature is complete until it has been implemented and tested.

## Features planned

- Lexical analysis of identifiers, numbers, relational operators, logical operators, and parentheses.
- Lexical errors for invalid characters or malformed tokens.
- Syntax analysis using the team's **final CFG**, including the agreed operator precedence and associativity.
- Abstract syntax tree (AST) generation.
- Semantic checks for declared identifiers and operand types, limited to the language features the team implements.
- Flask web interface to display the available compiler-stage outputs and errors.

## Technology

- Python 3
- Flask
- HTML, CSS, and JavaScript

## Repository layout

```text
expression-compiler/
├── lexer.py                  # Member 1: lexical analyzer
├── parser.py                 # Member 2: parser and AST
├── semantic.py               # Member 6: semantic analysis
├── app.py                    # Member 4: Flask entry point (confirm final filename)
├── templates/                # HTML templates
├── static/
│   ├── css/                  # Stylesheets
│   └── js/                   # Browser-side JavaScript
├── tests/                    # Valid and invalid test cases
├── docs/
│   ├── CONTRIBUTIONS.md      # Actual member contributions
│   ├── TESTING.md            # Test plan and actual results
│   └── PRESENTATION_CHECKLIST.md
├── requirements.txt
├── .gitignore
└── README.md
```

Adjust paths to match the filenames and folders used by the working application. Do not add empty placeholder Python files as if they were finished modules.

## Setup

1. Install Python 3 on your computer.
2. Clone or download this repository.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the Flask application using the actual entry-point filename. For example, if the entry point is `app.py`:

   ```bash
   python app.py
   ```

6. Open the local URL printed in the terminal (commonly `http://127.0.0.1:5000/`).

The run command and URL above must be confirmed against the final Flask implementation before submission.

## Testing

Record the exact test command(s) and actual outcomes in [`docs/TESTING.md`](docs/TESTING.md). Test individual stages as well as the integrated application. Include invalid-input cases and confirm that error messages are understandable.

## Team contributions

See [`docs/CONTRIBUTIONS.md`](docs/CONTRIBUTIONS.md). Record the work each person actually completed and use Git commits/pull requests to preserve an accurate project history.

## Grammar and language specification

Document the final CFG and grammar transformations supplied by the syntax-analysis member. State operator precedence and associativity explicitly. Avoid presenting a provisional grammar as the final one.

## Limitations

List known limitations here after integration and testing. Do not leave this section blank if there are meaningful limitations.
