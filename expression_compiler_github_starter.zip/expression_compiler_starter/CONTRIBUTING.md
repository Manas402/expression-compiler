# Contributing to Expression Compiler

## Team workflow

1. Pull the latest changes before starting work.
2. Work on the module assigned to you and avoid overwriting teammates' changes.
3. Test your change before committing it.
4. Use your own GitHub account and a commit message that describes the work.
5. Push a branch and open a pull request, or follow the team's agreed branch workflow.
6. Review the integrated application and fix merge or integration issues together.

## Example commands

```bash
git clone https://github.com/YOUR-USERNAME/expression-compiler.git
cd expression-compiler
git checkout -b feature/your-module
# Edit your assigned files and run the relevant tests.
git add path/to/your-file
git commit -m "Describe the change made"
git push -u origin feature/your-module
```

Replace the repository URL and file paths with the actual values. Commit only changes you made or are authorized to maintain. Never use another person's identity or imply they made a commit they did not make.

## Commit message examples

- `Implement lexical token recognition`
- `Add CFG-based parser and AST generation`
- `Add semantic identifier checks`
- `Connect compiler modules to Flask interface`
- `Document project setup and test results`
- `Add final project presentation`

## Before submission

- Ensure the application starts using the README instructions.
- Confirm all stated features exist in the code.
- Add actual test results and screenshots, not invented results.
- Keep secrets, virtual environments, and cache files out of the repository.
